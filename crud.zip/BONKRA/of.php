<?php

$con=new mysqli('localhost','root','','bonkra');

if(!$con){
    die(mysqli_error($con));
}
else 
{
echo" connected sucessfully"; }
?>